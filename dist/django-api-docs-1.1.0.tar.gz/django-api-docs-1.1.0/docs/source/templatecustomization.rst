Template Customization
======================


Override
--------

The default template can and should be overridden to reflect your brand and style.  To override, simply create a new template that resides in an api_docs/apis.html.  The basic looping
structure can be seen in the repo.  https://github.com/dstegelman/django-interactive-api-docs