#Overview

This application is based upon interactive API Docs from the Mashery.  Interactive docs allow your API consumers to see exactly
how your APIs are called and what results they should expect.  Take a look at api.stegelman.com for an example of how
this app is implemented.


## Read Some Docs

http://docs.derek.stegelman.com/django_api_docs/


## Pip

pip install git+git://github.com/dstegelman/django-interactive-api-docs.git

