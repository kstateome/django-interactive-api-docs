#Overview

This application is based upon interactive API Docs from the Mashery.  Interactive docs allow your API consumers to see exactly
how your APIs are called and what results they should expect.  Take a look at api.stegelman.com for an example of how
this app is implemented.


## Read Some Docs

http://readthedocs.org/docs/django-api-docs/en/latest/


## Pip

pip install django-api-docs

